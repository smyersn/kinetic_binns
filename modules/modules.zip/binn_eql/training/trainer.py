"""
Training loop for the BINN.

Trainer.fit runs the four-phase schedule of training/phases.py. Each epoch:

    1. configure the phase (learning rates, frozen sub-networks, loss weights)
    2. one optimization pass over the training data
    3. one evaluation pass over the validation data
    4. phase-specific model selection (best surface in Phase 1, best model
       and early stopping in Phase 4)
    5. logging and checkpointing

One-time work at phase boundaries (restoring the best surface, measuring the
loss scales) is done in _enter_phase.

With surface_ema_epochs set, Phase 1 also keeps a running average of the
surface's weights (training/ema.py). Validation, best-surface selection and
the surface restored for Phases 2-4 then all use the averaged weights.
"""
import contextlib
import os
import time

import torch

from modules.binn_eql.equations.extract import extract_params
from modules.binn_eql.equations.format import write_equations
from modules.binn_eql.training.checkpoint import (
    load_checkpoint, load_weights, save_checkpoint, save_weights)
from modules.binn_eql.training.ema import WeightEMA
from modules.binn_eql.training.phases import PhaseSchedule
from modules.utils.time_remaining import time_remaining

LOSS_KEYS = ('loss', 'gls', 'pde', 'reg', 'mass')


def _empty_param_history():
    return {'raw_w_unscaled': [], 'effective_unscaled': [], 'diffusion_coeffs': [], 'epoch': []}


class BestTracker:
    """Lowest value seen so far and the epoch at which it occurred."""

    def __init__(self, value=1e12, epoch=0):
        self.value, self.epoch = value, epoch

    @classmethod
    def from_history(cls, values, offset, default_epoch):
        """Best entry of a loss history (values[k] belongs to epoch offset + k)."""
        if not values:
            return cls(epoch=default_epoch)
        best = min(values)
        return cls(best, offset + values.index(best))

    def update(self, value, epoch, rel_threshold=0.0):
        """Record value if it improves on the best by more than rel_threshold. Returns True if so."""
        if (self.value - value) / self.value > rel_threshold:
            self.value, self.epoch = value, epoch
            return True
        return False


class Trainer:
    """
    Parameters
    ----------
    model        BINN
    loss_fn      BINNLoss for the same model
    optimizer    param groups named 'surface', 'reaction' and optionally 'diffusion'
    scheduler    stepped once per epoch during Phase 1 only
    out_dir      run directory (equation log, checkpoints, best weights)
    mass_weight  weight of the mass-conservation loss
    validation   Phases 2-4 validation loss, which drives Phase 4 model
                 selection and early stopping:
                   'sampled'     (legacy) PDE on random cache samples, one per
                                 validation batch -- noisy, and drawn from the
                                 same cache as training
                   'full_cache'  PDE over the whole cache in eval mode --
                                 deterministic
    checkpoint_minutes  wall-clock interval between resumable checkpoints
    physics_steps_per_epoch
                 reaction steps per epoch in Phases 2-4. None (default): one
                 per data batch, as originally -- so the step count grows
                 with the data size (points^2). An integer fixes it, so the
                 resolution of the data affects only the surface fit (Phase 1)
                 and runs at different resolutions get identical reaction
                 training.
    surface_ema_epochs
                 None (default): off. A number: during Phase 1, keep an
                 exponential moving average of the surface's weights spanning
                 roughly this many epochs, and use the averaged weights for
                 validation, best-surface selection and the surface restored
                 for Phases 2-4. Given in epochs so it means the same at any
                 data size; converted to a per-step decay in fit().
    """

    def __init__(self, model, loss_fn, optimizer, scheduler=None, out_dir='.',
                 save_prefix=None, mass_weight=1.0, validation='sampled',
                 log_every=1000, checkpoint_minutes=10.0, floor_track_every=100,
                 physics_steps_per_epoch=None, surface_ema_epochs=None):
        if validation not in ('sampled', 'full_cache'):
            raise ValueError(f"validation must be 'sampled' or 'full_cache', got {validation!r}")
        self.model = model
        self.loss_fn = loss_fn
        self.optimizer = optimizer
        self.scheduler = scheduler
        self.out_dir = out_dir
        self.save_prefix = save_prefix or os.path.join(out_dir, 'binn')
        self.mass_weight = mass_weight
        self.validation = validation
        self.physics_steps_per_epoch = physics_steps_per_epoch
        if surface_ema_epochs is not None and surface_ema_epochs <= 0:
            raise ValueError(f"surface_ema_epochs must be positive, got {surface_ema_epochs}")
        self.surface_ema_epochs = surface_ema_epochs
        self.surface_ema = None            # created in fit() if Phase 1 still has epochs to run
        self._pending_ema_state = None     # from a checkpoint, applied when the EMA is created
        self.log_every = log_every
        self.checkpoint_minutes = checkpoint_minutes
        self.floor_track_every = floor_track_every

        # The training script's param groups are the single source of truth
        # for LRs. Read 'max_lr' rather than 'lr': OneCycleLR overwrites
        # 'lr' with max_lr / div_factor when it is constructed.
        self.base_lrs = {pg.get('name'): pg.get('max_lr', pg['lr'])
                         for pg in optimizer.param_groups}

        self.train_loss_dict = {k: [] for k in LOSS_KEYS}
        self.val_loss_dict = {k: [] for k in LOSS_KEYS}
        self.param_history = _empty_param_history()
        self._surface_restored = False

    # ==================================================================
    # Main loop
    # ==================================================================
    def fit(self, train_data, val_data, epochs, batch_size, l0_weight=0.0,
            phase_ends=None, initial_epoch=0, early_stopping=None,
            phase1_early_stopping=None):
        """
        Train from initial_epoch up to epochs.

        phase_ends             (phase_1_end, phase_2_end, phase_3_end); default 5/20/30% of epochs
        early_stopping         Phase 4 patience, in epochs without val-loss improvement
        phase1_early_stopping  Phase 1 patience on val GLS; ends Phase 1 early
                               (later phases keep their end epochs)

        Returns (param_history, train_loss_dict, val_loss_dict).
        """
        schedule = PhaseSchedule(*phase_ends) if phase_ends else PhaseSchedule.default(epochs)
        schedule.validate(epochs)
        self._check_scheduler_length(schedule)

        data_steps = -(-len(train_data) // batch_size)   # ceil
        if self.physics_steps_per_epoch:
            print(f"Phases 2-4: {self.physics_steps_per_epoch} reaction steps per epoch "
                  f"(fixed; one per data batch would be {data_steps}).", flush=True)
        else:
            print(f"Phases 2-4: {data_steps} reaction steps per epoch (one per data batch).",
                  flush=True)

        if initial_epoch == 0:
            self.param_history = _empty_param_history()

        self._setup_surface_ema(initial_epoch, schedule, data_steps)

        # Best surface (Phase 1) and best model (Phase 4), recovered from the
        # loss history when resuming.
        best_surface = BestTracker.from_history(
            self.val_loss_dict['gls'][:schedule.phase_1_end], 0, initial_epoch)
        best_model = BestTracker.from_history(
            self.val_loss_dict['loss'][schedule.phase_3_end:], schedule.phase_3_end,
            max(initial_epoch, schedule.phase_3_end))
        self._surface_restored = initial_epoch >= schedule.phase_1_end

        device = train_data.device
        total_iter = initial_epoch + epochs
        start_time = epoch_start = last_checkpoint = time.time()
        current_phase = None
        epoch = initial_epoch

        for epoch in range(initial_epoch, epochs):
            epoch_start = time.time()
            phase = schedule.phase_at(epoch)
            entering = phase.number != current_phase

            # --- 1. Configure the phase ---------------------------------
            if entering:
                self._enter_phase(phase.number, train_data, best_surface)
            self._configure_phase(phase)
            if entering:
                self._print_phase_banner(phase.number, epoch)
                current_phase = phase.number

            weights = torch.tensor(
                [phase.gls_weight, phase.pde_weight,
                 schedule.l0_weight(phase, epoch, l0_weight, self.loss_fn.l0_scale)],
                device=device)

            if phase.number == 2 and epoch % self.floor_track_every == 0:
                self.loss_fn.track_pde_floor(epoch)
            if epoch % self.log_every == 0:
                self._snapshot_equation(epoch)

            # --- 2-3. Train and validate --------------------------------
            self._record(self.train_loss_dict,
                         self._run_epoch(train_data, batch_size, weights, phase, train=True))
            if self.scheduler is not None and phase.steps_scheduler:
                self.scheduler.step()
            # In Phase 1 with weight averaging, validate and select with the
            # averaged surface; the best one saved is what Phase 2 restores.
            averaged = (self.surface_ema.applied()
                        if self.surface_ema is not None and phase.number == 1
                        else contextlib.nullcontext())
            with averaged:
                self._record(self.val_loss_dict,
                             self._run_epoch(val_data, batch_size, weights, phase, train=False))

                # --- 4. Model selection ---------------------------------
                if phase.number == 1:
                    # GLS, not total loss: only the surface trains in Phase 1.
                    if best_surface.update(self.val_loss_dict['gls'][-1], epoch):
                        save_weights(self.model, self._weights_path('best_phase1'))

            if phase.number == 1:
                if (phase1_early_stopping is not None and self._scheduler_finished(epoch)
                        and epoch - best_surface.epoch >= phase1_early_stopping):
                    print(f"Phase 1 early stopping at epoch {epoch} (no val GLS "
                          f"improvement in {phase1_early_stopping} epochs)", flush=True)
                    schedule.phase_1_end = epoch + 1

            if phase.number == 4:
                if best_model.update(self.val_loss_dict['loss'][-1], epoch):
                    save_weights(self.model, self._weights_path('best_val'))
                if early_stopping is not None and epoch - best_model.epoch >= early_stopping:
                    print(f"Early stopping triggered at epoch {epoch}")
                    break

            # --- 5. Logging and checkpointing ---------------------------
            if epoch % self.log_every == 0:
                self._print_progress(epoch, start_time, epoch_start, batch_size, total_iter)
            # Checkpoints are written by wall-clock time: the histories grow
            # every epoch, so a fixed epoch interval makes saving ever costlier.
            if (time.time() - last_checkpoint >= 60 * self.checkpoint_minutes
                    or epoch == epochs - 1):
                self._save_checkpoint(epoch)
                last_checkpoint = time.time()

        self._print_summary(epoch, best_model.epoch, start_time, epoch_start, batch_size, total_iter)
        return self.param_history, self.train_loss_dict, self.val_loss_dict

    # ==================================================================
    # Phases
    # ==================================================================
    def _enter_phase(self, phase_number, train_data, best_surface):
        """
        One-time work at a phase boundary. Also runs when a resumed run
        starts mid-schedule, so the loss scales are rebuilt; each call is
        a no-op if its work has already been done.
        """
        if phase_number >= 2:
            # The PDE/mass scales and the collocation cache are measured from
            # the surface and then frozen, so the best Phase-1 surface must be
            # restored before they are computed.
            if not self._surface_restored:
                path = self._weights_path('best_phase1')
                if os.path.exists(path):
                    load_weights(self.model, path, device=train_data.device)
                    print(f"Restored best Phase-1 surface from epoch {best_surface.epoch} "
                          f"(val GLS = {best_surface.value:.4e})"
                          + (" [weight-averaged]" if self.surface_ema_epochs else ""),
                          flush=True)
                self.surface_ema = None       # Phase 1 is over; the average is no longer needed
                self._surface_restored = True
            self.loss_fn.calibrate_physics(train_data)

        if phase_number >= 3:
            # Start sparsification from the best reaction Phase 2 found.
            self.loss_fn.calibrate_l0()

    def _configure_phase(self, phase):
        """
        Set every param group's LR and every sub-network's requires_grad for
        this phase.

        In a phase where the scheduler steps (Phase 1), the scheduler owns
        the LR of the groups being trained; overwriting it here every epoch
        would pin them at base LR and disable the schedule. In every other
        phase the LR is set explicitly: a group left alone would inherit
        whatever OneCycleLR annealed it to at the end of Phase 1 (~4e-9).

        Frozen groups get LR 0. The scheduler may overwrite that in Phase 1,
        but frozen parameters receive no gradients and are skipped by the
        optimizer either way.
        """
        scheduled = phase.steps_scheduler and self.scheduler is not None
        for pg in self.optimizer.param_groups:
            name = pg.get('name')
            if name not in phase.trains:
                pg['lr'] = 0.0
            elif not scheduled:
                pg['lr'] = self.base_lrs.get(name, 0.0)

        subnets = {'surface': self.model.surface_fitter,
                   'reaction': self.model.reaction,
                   'diffusion': self.model.diffusion_fitter}
        for name, net in subnets.items():
            if net is not None:
                net.requires_grad_(name in phase.trains)

    def _setup_surface_ema(self, initial_epoch, schedule, data_steps):
        """Create the Phase 1 surface weight average, if enabled and Phase 1 is not over."""
        if not self.surface_ema_epochs or initial_epoch >= schedule.phase_1_end:
            return
        steps = self.surface_ema_epochs * data_steps
        decay = 1.0 - 1.0 / max(steps, 1.0)
        self.surface_ema = WeightEMA(self.model.surface_fitter, decay)
        print(f"Phase 1 surface weight averaging over ~{self.surface_ema_epochs:g} epochs "
              f"({data_steps} steps/epoch, decay {decay:.6f}); validation, best-surface "
              f"selection and the restored surface use the average.", flush=True)
        if self._pending_ema_state is not None:
            self.surface_ema.load_state_dict(self._pending_ema_state)
            print(f"Resumed the surface weight average "
                  f"({self.surface_ema.num_updates} updates so far).", flush=True)
        elif initial_epoch > 0:
            print("Checkpoint has no surface weight average; it restarts from the "
                  "current weights.", flush=True)
        self._pending_ema_state = None

    def _check_scheduler_length(self, schedule):
        steps = getattr(self.scheduler, 'total_steps', None)
        if steps is not None and steps != schedule.phase_1_end:
            print(f"WARNING: scheduler total_steps={steps} != phase_1_end="
                  f"{schedule.phase_1_end}. The scheduler only steps during Phase 1, "
                  f"so Phase 1 will end mid-ramp (or the ramp will finish early).", flush=True)

    def _scheduler_finished(self, epoch):
        """
        True once OneCycleLR is 90% through. Validation loss rises at peak LR
        and falls during the anneal, so patience-based stopping before then
        tends to fire just before the improvement it is waiting for.
        """
        if self.scheduler is None:
            return True
        return epoch >= int(0.9 * getattr(self.scheduler, 'total_steps', 0))

    # ==================================================================
    # One pass over the data
    # ==================================================================
    def _run_epoch(self, data, batch_size, weights, phase, train):
        """
        One training or validation pass. Returns per-sample mean losses.

        Phase 1 fits the surface to the data. In Phases 2-4 the surface is
        frozen and GLS carries zero weight, so the data only set the number
        of steps: each step draws fresh collocation points instead.
        """
        uses_data = 'surface' in phase.trains or phase.gls_weight > 0
        if uses_data:
            return self._data_epoch(data, batch_size, weights, phase, train)
        if not train and self.validation == 'full_cache':
            return self._full_cache_validation(weights, phase)
        return self._physics_epoch(len(data), batch_size, weights, phase, train)

    def _data_epoch(self, data, batch_size, weights, phase, train):
        """Phase 1: minibatches of data through the surface fitter."""
        self.model.train(train)
        species = self.model.species
        order = torch.randperm(len(data)) if train else torch.arange(len(data))
        totals = torch.zeros(len(LOSS_KEYS), device=data.device)

        for start in range(0, len(data), batch_size):
            batch = data[order[start:start + batch_size]]
            inputs, targets = batch[:, :-species], batch[:, -species:]
            if train:
                self.optimizer.zero_grad()
            terms = self.loss_fn(inputs, self.model(inputs), targets, phase.number)
            totals += self._step(terms, weights, phase, train) * len(inputs)

        return self._to_means(totals, len(data))

    def _physics_epoch(self, n_samples, batch_size, weights, phase, train):
        """
        Phases 2-4: steps on freshly sampled collocation points; the data are
        never touched. The step count is physics_steps_per_epoch if set,
        otherwise one per data batch, weighted by the batch sizes so the
        logged losses match what a data-driven pass would record.
        """
        if self.physics_steps_per_epoch:
            step_weights = [1] * self.physics_steps_per_epoch
        else:
            step_weights = [min(batch_size, n_samples - start)
                            for start in range(0, n_samples, batch_size)]

        self.model.train(train)
        totals = torch.zeros(len(LOSS_KEYS), device=self.model.lb.device)

        # Validation needs no autograd graph, except on the uncached path,
        # which differentiates the surface to get u_t and lap u.
        with torch.set_grad_enabled(train or self.loss_fn.cache is None):
            for w in step_weights:
                if train:
                    self.optimizer.zero_grad()
                terms = self.loss_fn.physics_terms()
                totals += self._step(terms, weights, phase, train) * w

        return self._to_means(totals, sum(step_weights))

    def _full_cache_validation(self, weights, phase):
        """Phases 2-4, validation='full_cache': one deterministic evaluation over the whole cache."""
        self.model.eval()
        terms = self.loss_fn.full_cache_terms()
        if terms is None:
            raise RuntimeError("full_cache validation needs the collocation cache, "
                               "which is built at Phase 2 entry.")
        with torch.no_grad():
            return self._to_means(self._step(terms, weights, phase, train=False), 1)

    def _step(self, terms, weights, phase, train):
        """
        Combine the loss terms, take an optimizer step if training, and return
        the logged quantities as a GPU tensor ordered like LOSS_KEYS. Nothing
        here synchronizes with the host, so the CPU can queue work ahead.
        """
        weighted = torch.stack([terms.gls, terms.pde, terms.l0]) * weights
        mass = (self.mass_weight * terms.mass if phase.mass_active
                else torch.zeros((), device=weighted.device))
        total = weighted.sum() + terms.soft_wall + mass

        if train:
            total.backward()
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            self.optimizer.step()
            if self.surface_ema is not None and 'surface' in phase.trains:
                self.surface_ema.update()

        return torch.stack([total, weighted[0], weighted[1],
                            weighted[2] + terms.soft_wall, mass]).detach()

    @staticmethod
    def _to_means(totals, n):
        """Single host sync per pass: divide and copy all logged losses at once."""
        return dict(zip(LOSS_KEYS, (totals / n).tolist()))

    @staticmethod
    def _record(history, losses):
        for k, v in losses.items():
            history[k].append(v)

    # ==================================================================
    # Logging
    # ==================================================================
    def _diffusion_values(self):
        return [D.item() for D in self.model.diffusion_fitter()]

    def _snapshot_equation(self, epoch):
        """Append the current equation to equation.txt and record coefficients in param_history."""
        path = os.path.join(self.out_dir, 'equation.txt')
        write_equations(path, self.model, header=f'Equation Epoch {epoch}')
        with open(path, 'a') as f:
            f.write('\n')
            if self.model.learns_diffusion:
                f.write(f'{self._diffusion_values()}\n\n')

        snapshot = extract_params(self.model, full=False)
        self.param_history['epoch'].append(epoch)
        self.param_history['raw_w_unscaled'].append([p['raw_w_unscaled'] for p in snapshot])
        self.param_history['effective_unscaled'].append([p['effective_unscaled'] for p in snapshot])
        if self.model.learns_diffusion:
            self.param_history['diffusion_coeffs'].append(self._diffusion_values())

    def _print_phase_banner(self, phase_number, epoch):
        lrs = ", ".join(f"{pg.get('name')}={pg['lr']:.2e}" for pg in self.optimizer.param_groups)
        print(f"=== Phase {phase_number} @ epoch {epoch} | lrs: {lrs} ===\n", flush=True)

    def _print_progress(self, epoch, start_time, epoch_start, batch_size, total_iter):
        _, remaining, _ = time_remaining(
            current_iter=epoch + 1, total_iter=total_iter, start_time=start_time,
            previous_time=epoch_start, ops_per_iter=batch_size)
        train, val = self.train_loss_dict, self.val_loss_dict

        line = (f"Epoch {epoch} | Train loss = {train['loss'][-1]:.4e}"
                f" | Val loss = {val['loss'][-1]:.4e}"
                f" | Val GLS = {val['gls'][-1]:.4e}, Val PDE = {val['pde'][-1]:.4e},"
                f" Val Reg = {val['reg'][-1]:.4e} Val Mass = {val['mass'][-1]:.4e}")
        if self.model.learns_diffusion:
            line += ' | ' + ', '.join(f'D{name}={D:.4e}' for name, D in
                                      zip(self.model.species_names, self._diffusion_values()))
        print(f"{line} | Remaining = {remaining}           ", flush=True)

    def _print_summary(self, epoch, best_epoch, start_time, epoch_start, batch_size, total_iter):
        """Final line: the losses of the selected (best Phase-4) model."""
        elapsed, _, _ = time_remaining(
            current_iter=epoch + 1, total_iter=total_iter, start_time=start_time,
            previous_time=epoch_start, ops_per_iter=batch_size)
        i = best_epoch if best_epoch < len(self.val_loss_dict['loss']) else -1
        train, val = self.train_loss_dict, self.val_loss_dict
        print(f"Epoch {epoch} | Train loss = {train['loss'][i]:.4e}"
              f" | Val loss = {val['loss'][i]:.4e}"
              f" | Val GLS = {val['gls'][i]:.4e}, Val PDE = {val['pde'][i]:.4e},"
              f" Val Reg = {val['reg'][i]:.4e} | Elapsed = {elapsed}           ", flush=True)

    # ==================================================================
    # Persistence
    # ==================================================================
    def _weights_path(self, tag):
        return f"{self.save_prefix}_{tag}_model"

    def _save_checkpoint(self, epoch):
        save_checkpoint(
            os.path.join(self.out_dir, 'latest_checkpoint.pt'),
            epoch=epoch, model=self.model, optimizer=self.optimizer, scheduler=self.scheduler,
            train_losses=self.train_loss_dict, val_losses=self.val_loss_dict,
            param_history=self.param_history, loss_state=self.loss_fn.state_dict(),
            extra={'surface_ema': (self.surface_ema.state_dict()
                                   if self.surface_ema is not None else None)})

    def resume(self, path, device='cuda'):
        """Restore a checkpoint written by this Trainer. Returns the epoch to resume from."""
        epoch, checkpoint = load_checkpoint(path, self.model, self.optimizer, self.scheduler, device)
        self.train_loss_dict = checkpoint['train_loss_dict']
        self.val_loss_dict = checkpoint['val_loss_dict']
        self.param_history = checkpoint['param_history']
        self._pending_ema_state = checkpoint.get('surface_ema')
        if 'loss_state' in checkpoint:
            self.loss_fn.load_state_dict(checkpoint['loss_state'])
        else:
            print("Checkpoint predates saved loss state: if resuming past Phase 2, "
                  "the L0 scale will be re-measured from the current weights.", flush=True)
        return epoch

    def load(self, path, device=None):
        """Load model weights (e.g. binn_best_val_model) and switch to eval mode."""
        load_weights(self.model, path, device=device)
        self.model.eval()

    def predict(self, inputs):
        self.model.eval()
        return self.model(inputs)